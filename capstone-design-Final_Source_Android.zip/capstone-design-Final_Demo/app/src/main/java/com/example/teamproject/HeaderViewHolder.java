package com.example.teamproject;

import android.view.View;

import androidx.recyclerview.widget.RecyclerView;

public class HeaderViewHolder extends RecyclerView.ViewHolder {
    HeaderViewHolder(View headerView) {
        super(headerView);
    }
}
