package com.example.teamproject;

import java.util.ArrayList;

public class commentList {


    ArrayList<commentResult> comment = new ArrayList<commentResult>();
}
