package com.example.teamproject;

public class commentResult {

    String board_title;
    String cmt_context;
    String cmt_nickname;
}
