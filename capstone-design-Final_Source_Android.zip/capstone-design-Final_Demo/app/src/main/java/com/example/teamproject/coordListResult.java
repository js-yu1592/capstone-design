package com.example.teamproject;

public class coordListResult {
    double lon;
    double lat;

}
