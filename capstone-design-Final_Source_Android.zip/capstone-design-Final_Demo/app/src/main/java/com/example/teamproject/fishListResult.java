package com.example.teamproject;

public class fishListResult {
    int fish_num;
    String fish_uid;
    String fish_name;
    String fish_length;
    String fish_weight;
    String fish_comment;
    String fish_lat;
    String fish_lon;
    String createdAt;
    String updatedAt;
    String fish_fishing;

    public int getFish_num() {
        return fish_num;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public String getFish_comment() {
        return fish_comment;
    }

    public String getFish_fishing() {
        return fish_fishing;
    }

    public String getFish_lat() {
        return fish_lat;
    }

    public String getFish_length() {
        return fish_length;
    }

    public String getFish_lon() {
        return fish_lon;
    }

    public String getFish_name() {
        return fish_name;
    }

    public String getFish_uid() {
        return fish_uid;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public String getFish_weight() {
        return fish_weight;
    }
}
