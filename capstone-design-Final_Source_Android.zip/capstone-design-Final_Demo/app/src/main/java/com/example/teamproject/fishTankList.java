package com.example.teamproject;

import java.util.ArrayList;

public class fishTankList {


    ArrayList<fishListResult> fish = new ArrayList<fishListResult>();
}
