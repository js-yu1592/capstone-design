package com.example.teamproject;

public class mainListResult {
    String temp;
    String feels_like;
    String temp_min;
    String temp_max;
    String humidity;
}
