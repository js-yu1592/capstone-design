package com.example.teamproject;

import java.util.ArrayList;

public class myNicknameList {
    ArrayList<myNicknameResult> my_nickname=new ArrayList<myNicknameResult>();
}