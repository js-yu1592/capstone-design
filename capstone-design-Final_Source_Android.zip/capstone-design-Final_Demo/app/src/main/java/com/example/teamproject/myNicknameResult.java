package com.example.teamproject;

public class myNicknameResult {
    String user_nickname;

    public String getNickname() {
        return user_nickname;
    }

    public void setNickname(String nickname) {
        this.user_nickname = user_nickname;
    }


}