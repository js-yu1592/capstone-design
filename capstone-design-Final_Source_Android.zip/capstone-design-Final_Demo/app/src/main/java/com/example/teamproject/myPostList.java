package com.example.teamproject;

import java.util.ArrayList;

public class myPostList {
    ArrayList<myPostResult> my_board=new ArrayList<myPostResult>();
}
