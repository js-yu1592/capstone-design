package com.example.teamproject;

import java.util.ArrayList;

public class myProfileList {
    ArrayList<myProfileResult> my_profile=new ArrayList<myProfileResult>();
}
