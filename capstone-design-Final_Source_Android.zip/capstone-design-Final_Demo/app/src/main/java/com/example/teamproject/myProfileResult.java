package com.example.teamproject;

public class myProfileResult {

    String user_name;
    String user_nickname;
    String user_email;
    String user_phone;
}
