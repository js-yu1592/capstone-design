package com.example.teamproject;

public class sysListResult {
    String country;
    int sunrise;
    int sunset;
}
