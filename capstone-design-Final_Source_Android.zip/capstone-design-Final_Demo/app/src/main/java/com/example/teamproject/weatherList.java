package com.example.teamproject;

import java.util.ArrayList;

public class weatherList {
    coordListResult coord;
    ArrayList<weatherListResult> weather=new ArrayList<weatherListResult>();
    mainListResult main;
    windListResult wind;
    sysListResult sys;
    String name;
}
