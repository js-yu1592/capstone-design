package com.example.teamproject;

public class weatherListResult {
    String main;
    String description;
}
