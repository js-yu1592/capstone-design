package com.example.teamproject;

public class windListResult {
    double speed;
    int deg;
}
