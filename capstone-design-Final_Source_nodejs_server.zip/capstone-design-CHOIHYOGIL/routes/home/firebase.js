


var firebaseConfig = {
    apiKey: "AIzaSyA5I8jNkgH19JGRXPVz523OCAQHGjAxSYw",
    authDomain: "graduation-f5a8d.firebaseapp.com",
    databaseURL: "https://graduation-f5a8d.firebaseio.com",
    projectId: "graduation-f5a8d",
    storageBucket: "graduation-f5a8d.appspot.com",
    messagingSenderId: "767170513426",
    appId: "1:767170513426:web:3926482e507c84c72d26cb",
    measurementId: "G-J08EVYWLEL"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);
  firebase.analytics();